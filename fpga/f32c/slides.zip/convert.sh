#!/bin/sh

rm slides/*
cd source

for file in *.png
do
  echo $file
  convert $file -scale 624x480 ../slides/$(basename $file .png).ppm
done

for file in *.jpg
do
  echo $file
  convert $file -scale 624x480 ../slides/$(basename $file .jpg).ppm
done

for file in *.gif
do
  echo $file
  convert $file -scale 624x480 ../slides/$(basename $file .gif).ppm
done

for file in *.ppm
do
  echo $file
  convert $file -scale 624x480 ../slides/$(basename $file .ppm).ppm
done
